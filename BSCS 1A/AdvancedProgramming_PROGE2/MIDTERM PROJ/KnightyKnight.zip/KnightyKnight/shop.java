import javax.swing.*;
import java.util.Scanner;

public class shop {
   Scanner sc = new Scanner(System.in);
   int hp_mod = 0;
   int sp_mod = 0;
   int atk_mod = 0;
   int eva_mod = 0;
   int gold = 10;
   int dmg = 1;
   String cont = "no";
   String weapon = "Stick [ATK: +0 // DMG: 1]";
   String armor = "Clothes [+0 Max HP // +0 EVA // +0 Max SP]";


   boolean Shopping = true;
   player player = new player();


   void barnesDecline () {
       JOptionPane.showMessageDialog(
               null, // parentComponent
               "BARNES: Ya tryin' to fleece me, kid? Come back when you're richer.", // message
               "-- NOT ENOUGH GOLD --", // title
               JOptionPane.PLAIN_MESSAGE
       );
   }


   void showStats() {
       System.out.println("Player HP:  " + player.player_HP);
       System.out.println("Player SP:  " + player.player_SP);
       System.out.println("Player EVA:  " + player.player_eva);
       System.out.println("Player DMG:  " + dmg);
       System.out.println("Player Gold:  " + gold);
       System.out.println("Current Weapon: " + weapon);
       System.out.println("Current Armor: " + armor);
   }


   void showShop() {
       System.out.println("Current Stats: ");
       showStats();


       while (Shopping) {
           int shop_select = Integer.parseInt(JOptionPane.showInputDialog(
                   null, // parentComponent
                   "BARNES looks at you with a toothy grin, presenting 3 choices... "
                   + "\n1. Weapons" + "\n2. Armor" + "\n3. Exit" + "\nBARNES: What'll it be? ", // message
                   "-- SHOP --", // title
                   JOptionPane.PLAIN_MESSAGE
           ));
           switch (shop_select) {
               case 1:
                   int weapon_bought = 0;


                   int weapon_select = Integer.parseInt(JOptionPane.showInputDialog(
                           null, // parentComponent
                           "1. [20 GOLD] Greataxe: // ATK: +10 // DMG: 12"
                                   + "\n2. [10 GOLD] Sword: // ATK: +3 // DMG: 8" + "\n3. [10 GOLD] Crossbow: // ATK: +5 // DMG 6", // message
                           "-- WEAPONRY --", // title
                           JOptionPane.PLAIN_MESSAGE
                   ));
                   switch (weapon_select) {
                       case 1:
                           if (gold < 20){
                               barnesDecline();
                               Shopping = false;
                           }
                           else {
                               weapon = "Greataxe: // ATK: +10 // DMG: 12";
                               atk_mod += 10;
                               dmg = 12;
                               gold -= 20;
                           }


                           break;
                       case 2:
                           if (gold < 10){
                               barnesDecline();
                               Shopping = false;
                           } else {
                               weapon = "Sword: // ATK: +3 // DMG: 8";
                               atk_mod += 3;
                               sp_mod = 8;
                               gold -= 10;
                           }
                           break;
                       case 3:
                           if (gold < 10){
                               barnesDecline();
                               Shopping = false;
                           } else {
                               weapon = "Crossbow: // ATK: +5 // DMG 6 ";
                               atk_mod += 5;
                               dmg = 6;
                               gold -= 10;
                           }
                           break;
                       default:
                           System.out.print("Eh? Ya snooze ya lose, kid. Beat it.");
                           Shopping = false;
                           break;
                   }
                   break;




               case 2:
                   int armour_select = Integer.parseInt(JOptionPane.showInputDialog(
                           null, // parentComponent
                           "1. [10 GOLD] Jester Hat: // HP: +10 // EVA: +5"
                                   + "\n2. [20 GOLD] Blue Flaglet: // HP: -15 // EVA: +10" + "\n3. [30 GOLD] Tank: // HP: +50 // EVA: -10", // message
                           "-- ARMOUR --", // title
                           JOptionPane.PLAIN_MESSAGE
                   ));
                   switch (armour_select) {
                       case 1:
                           if (gold < 20){
                               barnesDecline();
                               Shopping = false;
                           } else {
                               weapon = "Jester Hat: // HP: +10 // EVA: +5";
                               hp_mod = 10;
                               dmg = 12;
                               gold -= 20;
                           }
                           break;
                       case 2:
                           if (gold < 10){
                               barnesDecline();
                               Shopping = false;
                           } else {
                               weapon = "Blue Flaglet: // HP: -15 // EVA: +10";
                               hp_mod = -15;
                               dmg = 8;
                               gold -= 10;
                           }
                           break;
                       case 3:
                           if (gold < 30){
                               barnesDecline();
                               Shopping = false;
                           } else {
                               weapon = "Tank: // HP: +50 // EVA: -10 ";
                               hp_mod = 50;
                               dmg = 8;
                               gold -= 10;
                           }
                           break;




                   }
                   break;
           }
           showStats();


           Shopping = false;
       }
   }
}



