import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       boolean menu = true;

       // calling classes
       shop shop = new shop();
       fight fight = new fight();
       builder builder = new builder();

       JOptionPane.showMessageDialog(
               null, // parentComponent
               "Welcome to the realm of KNIGHTY KNIGHT!", // message
               "Knighty Night", // title
               JOptionPane.INFORMATION_MESSAGE
       );


       while (menu) {
           int menu_choice = Integer.parseInt(JOptionPane.showInputDialog(
                   null, // parentComponent
                   "A sprawling pathway unfurls before you..." +
                           "\n1. FIGHT!" +
                           "\n2. Shop." +
                           "\n3. Character Builder." +
                           "\n4. Exit." +
                           "\nWhat do you do? (1-4): ", // message
                   "Knighty Night Fields", // title
                   JOptionPane.QUESTION_MESSAGE
           ));


           switch (menu_choice) {
               case 1:
                JOptionPane.showMessageDialog(
                           null, // parentComponent
                           "ROUGE the Knight valiantly strides over!", // message
                           "-- EN GARDE! --", // title
                           JOptionPane.PLAIN_MESSAGE
                   );
                   fight.showFight();
                   break;


               case 2:
                   JOptionPane.showMessageDialog(
                           null, // parentComponent
                           "BARNES: Ey, what can I get ya fer?", // message
                           "-- WELCOME TO BARNES' INN --", // title
                           JOptionPane.PLAIN_MESSAGE
                   );
                   shop.Shopping = true;
                   shop.showShop();
                   break;

               case 3:
                JOptionPane.showMessageDialog(
                           null, // parentComponent
                           "BARNES: Psst, kid. Wanna know a way you can get stronger?", // message
                           "-- BARNES' ALLEYWAY --", // title
                           JOptionPane.PLAIN_MESSAGE
                   );
                   builder.showBuilder();
                   break;


               case 4:
                   JOptionPane.showMessageDialog(
                           null, // parentComponent
                           "Thank you for reading with us. Knighty Knight bids thee farewell!", // message
                           "-- EXIT --", // title
                           JOptionPane.PLAIN_MESSAGE
                   );
                   menu = false;
                   break;


               default:
                   break;
           }


       }
   }
}



