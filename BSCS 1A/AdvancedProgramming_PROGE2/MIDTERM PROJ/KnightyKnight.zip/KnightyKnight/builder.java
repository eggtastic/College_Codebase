import java.util.Scanner;

import javax.swing.JOptionPane;

public class builder {
   boolean Upgrading = true;
   boolean Checking = true;
   boolean Stat_Shop = true;
   player player = new player();
   int Stat_Points = 0;
   int chosen_stat = 0;
   int stat_index = 0;
   String cont;
    Scanner sc = new Scanner(System.in);

   void check () {
        System.out.print("Would you like to continue upgrading your stats?(y/n): ");
        cont = sc.nextLine();

        if (cont.toLowerCase().equals("y")) {
            Upgrading = true;
        } else if (cont.toLowerCase().equals("n")) {
            Stat_Shop = false;
        } 
   }

   void showBuilder() {
       while (Stat_Shop) {

           System.out.println("1. Player HP:  " + player.player_HP);
           System.out.println("2. Player SP:  " + player.player_SP);
           System.out.println("3. Player EVA:  " + player.player_eva);
           System.out.println("4. Player ATK:  " + player.player_atk);
           System.out.print("You have " + Stat_Points + " Stat Points. What would you like to upgrade? ");
           int Stat_Select = sc.nextInt();

           switch (Stat_Select) {
               case 1:
                chosen_stat = player.player_HP;
                stat_index = 1;
                   Upgrading = true;
                   Checking = true;
                   System.out.print("You have " + chosen_stat + " Base HP. How many points would you like to put in? ");
                       break;
                case 2:
                   chosen_stat = player.player_SP;
                    stat_index += 2;
                   Upgrading = true;
                   Checking = true;
                   System.out.print("You have " + chosen_stat + " Base SP. How many points would you like to put in? ");
                       break;
                case 3:
                   chosen_stat = player.player_eva;
                stat_index += 3;
                   Upgrading = true;
                   Checking = true;
                   System.out.print("You have " + chosen_stat + " Base EVA. How many points would you like to put in? ");
                       break;
                case 4:
                   chosen_stat = player.player_atk;
                stat_index += 1;
                   Upgrading = true;
                   Checking = true;
                   System.out.print("You have " + chosen_stat + " Base ATK. How many points would you like to put in? ");
                       break;
                    default:
                        System.out.println("INPUT ERROR. Please try again!");
                        break;
                   }
                
                String stat = "Base";
                if (stat_index == 1){
                    stat = "HP";
                    stat_index = 0;
                } else if (stat_index == 2){
                    stat = "SP";
                    stat_index = 0;
                } else if (stat_index == 3){
                    stat = "EVA";
                    stat_index = 0;
                } else if (stat_index == 4){
                    stat = "ATK";
                    stat_index = 0;
                }

                while (Upgrading) {
                       int Upgrade = sc.nextInt();
                       sc.nextLine();
                       if (Upgrade <= Stat_Points) {
                           chosen_stat += Upgrade;
                           System.out.println("You now have " + chosen_stat + " Base " + stat);
                           Upgrading = false;
                       } else {
                            JOptionPane.showMessageDialog(
                                null, // parentComponent
                                "BARNES: Fight more, kid. Rack 'em up.", // message
                                "NOT ENOUGH SKILL PTS", // title
                                JOptionPane.INFORMATION_MESSAGE
                            );
                           Upgrading = false;
                       }
                   }
                   check();
                   
                }
            
           }
       
   
}

