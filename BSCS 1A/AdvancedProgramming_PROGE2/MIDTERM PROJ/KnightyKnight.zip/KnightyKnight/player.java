public class player {
   String name;
   int player_HP = 20;
   int player_SP = 20;
   int player_eva = 8;
   int player_atk = 10;
}


